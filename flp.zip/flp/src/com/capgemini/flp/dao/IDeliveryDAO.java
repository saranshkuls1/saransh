package com.capgemini.flp.dao;

import java.util.ArrayList;

import com.capgemini.flp.model.DeliveryDetails;

public interface IDeliveryDAO {
	public ArrayList<DeliveryDetails> getAllDetails();


}
