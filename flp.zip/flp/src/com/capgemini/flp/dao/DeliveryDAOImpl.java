package com.capgemini.flp.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.flp.model.DeliveryDetails;

@Repository
public class DeliveryDAOImpl implements IDeliveryDAO {

	@PersistenceContext
	EntityManager manager;

	/*@Override
	public ArrayList<HotelDetails> getAllHotels() {
		ArrayList<HotelDetails> list = new ArrayList<>();
		String jpql = "Select hotel from HotelDetails hotel";
		TypedQuery<HotelDetails> query = manager.createQuery(jpql, HotelDetails.class);
		list = (ArrayList<HotelDetails>) query.getResultList();
		return list;
	}*/

	

	@Override
	public ArrayList<DeliveryDetails> getAllDetails() {
		ArrayList<DeliveryDetails> list = new ArrayList<>();
		String jpql = "Select delivery from DeliveryDetails delivery";
		TypedQuery<DeliveryDetails> query = manager.createQuery(jpql, DeliveryDetails.class);
		list = (ArrayList<DeliveryDetails>) query.getResultList();
		return list;
	}
}
