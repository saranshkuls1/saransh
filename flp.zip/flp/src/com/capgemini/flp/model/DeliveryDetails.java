package com.capgemini.flp.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "delivery")
public class DeliveryDetails {

	@Id
	private Integer deliveryId;
	private Integer productId;
	private String customername;
	private String address;
	private Double  amount;
	private String orderDate;
	private String deliveryDate;
	private Long mobile;
	private String email;
	

	public DeliveryDetails() {

	}


	public Integer getDeliveryId() {
		return deliveryId;
	}


	public void setDeliveryId(Integer deliveryId) {
		this.deliveryId = deliveryId;
	}


	public Integer getProductId() {
		return productId;
	}


	public void setProductId(Integer productId) {
		this.productId = productId;
	}


	public String getCustomername() {
		return customername;
	}


	public void setCustomername(String customername) {
		this.customername = customername;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public Double getAmount() {
		return amount;
	}


	public void setAmount(Double amount) {
		this.amount = amount;
	}


	public String getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}


	public String getDeliveryDate() {
		return deliveryDate;
	}


	public void setDeliveryDate(String deliveryDate) {
		this.deliveryDate = deliveryDate;
	}


	public Long getMobile() {
		return mobile;
	}


	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public DeliveryDetails(Integer deliveryId, Integer productId,
			String customername, String address, Double amount, String orderDate,
			String deliveryDate, Long mobile, String email) {
		super();
		this.deliveryId = deliveryId;
		this.productId = productId;
		this.customername = customername;
		this.address = address;
		this.amount = amount;
		this.orderDate = orderDate;
		this.deliveryDate = deliveryDate;
		this.mobile = mobile;
		this.email = email;
	}


	@Override
	public String toString() {
		return "DeliveryDetails [deliveryId=" + deliveryId + ", productId="
				+ productId + ", customername=" + customername + ", address="
				+ address + ", amount=" + amount + ", orderDate=" + orderDate
				+ ", deliveryDate=" + deliveryDate + ", mobile=" + mobile
				+ ", email=" + email + "]";
	}

}
