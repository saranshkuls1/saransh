package com.capg.pp.cust_exception;

public class CustomerNotFound extends Exception {         //Exceptions handler

	private String status;

	public CustomerNotFound() {
		status = "Customer Not Found";
	}

	public CustomerNotFound(String status) {
		super();
		this.status = status;
	}

	@Override
	public String toString() {
		return "CustomerNotFound [status=" + status + "]";
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
