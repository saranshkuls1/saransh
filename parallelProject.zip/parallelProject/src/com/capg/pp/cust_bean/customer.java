package com.capg.pp.cust_bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;

@Entity
public class customer {                                                   // Bean class
	@Id
	@Column(name = "accountNo", length = 30, nullable = false)										// Defining columns for table
	private int accountNo;
	@Column(name = "c_name", length = 30, nullable = false)
	private String c_name;

	@Column(name = "c_addr", length = 30, nullable = false)
	private String c_addr;

	@Column(name = "c_email", length = 30, nullable = false)
	private String c_email;

	@Column(name = "c_ph", length = 30, nullable = false)
	private String c_ph;

	@Column(name = "c_pan", length = 30, nullable = false)
	private String c_pan;

	@Column(name = "c_adhar", length = 30, nullable = false)
	private String c_adhar;

	private int accPin;

	@Column(name = "balance", length = 30, nullable = false)
	private double balance;

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getC_name() {
		return c_name;
	}

	public void setC_name(String c_name) {
		this.c_name = c_name;
	}

	public String getC_addr() {
		return c_addr;
	}

	public void setC_addr(String c_addr) {
		this.c_addr = c_addr;
	}

	public String getC_email() {
		return c_email;
	}

	public void setC_email(String c_email) {
		this.c_email = c_email;
	}

	public String getC_ph() {
		return c_ph;
	}

	public void setC_ph(String c_ph) {
		this.c_ph = c_ph;
	}

	public String getC_pan() {
		return c_pan;
	}

	public void setC_pan(String c_pan) {
		this.c_pan = c_pan;
	}

	public String getC_adhar() {
		return c_adhar;
	}

	public void setC_adhar(String c_adhar) {
		this.c_adhar = c_adhar;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int account) {
		this.accountNo = account;
	}

	public int getAccPin() {
		return accPin;
	}

	public void setAccPin(int accpin2) {
		this.accPin = accpin2;
	}

	@Override
	public String toString() {
		return "customer [ c_name=" + c_name + ", c_addr=" + c_addr
				+ ", c_email=" + c_email + ", c_ph=" + c_ph + ", c_pan="
				+ c_pan + ", c_adhar=" + c_adhar + ", accountNo=" + accountNo
				+ ", accPin=" + accPin + ", balance=" + balance + "]";
	}

}
