package com.capg.pp.cust_bean;

public @interface Id {

}
