package com.capg.pp.cust_bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PrintTransaction {

@Id

@GeneratedValue(strategy=GenerationType.IDENTITY) 
 
private	Integer Sr_No;
	private Integer accountNumber;
	private String transactions;

	
	public int getSr_No() {
		return Sr_No;
	}

	public void setSr_No(int sr_No) {
		Sr_No = sr_No;
	}

	
	public Integer getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getTransactions() {
		return transactions;
	}

	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}

	@Override
	public String toString() {
		return "PrintTransaction [Sr_No=" + Sr_No + ", accountNumber="
				+ accountNumber + ", transactions=" + transactions + "]";
	}

	

}
