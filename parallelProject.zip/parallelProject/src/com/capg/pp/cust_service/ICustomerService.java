package com.capg.pp.cust_service;

import java.util.List;

import com.capg.pp.cust_bean.PrintTransaction;
import com.capg.pp.cust_bean.customer;
import com.capg.pp.cust_exception.CustomerNotFound;

public interface ICustomerService { // Service class Interface
	public int addCustomer(customer c) throws CustomerNotFound;

	public boolean withdrawlAmt(double amt, int accNo, int pin) // methods
																// declaration
			throws CustomerNotFound;

	public boolean depositAmt(int accNo1, double amt1) throws CustomerNotFound;

	public boolean show_balance(int accno3, int pin2) throws CustomerNotFound;

	public boolean fundTransfer(int source_accno, int s_pin,
			int destination_accno, Double transferAmt) throws CustomerNotFound;

	public List<PrintTransaction> printTransaction(int account)
			throws CustomerNotFound;

}
