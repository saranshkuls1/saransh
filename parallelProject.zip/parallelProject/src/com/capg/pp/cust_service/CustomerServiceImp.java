package com.capg.pp.cust_service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.pp.cust_bean.PrintTransaction;
import com.capg.pp.cust_bean.customer;
import com.capg.pp.cust_dao.CustomerDaoImplementation;
import com.capg.pp.cust_exception.CustomerNotFound;

public class CustomerServiceImp implements ICustomerService { // Implementation
																// for Service InterfaceClass

															
	CustomerDaoImplementation dao = new CustomerDaoImplementation();

	public int addCustomer(customer c) throws CustomerNotFound {

		return dao.addCustomer(c);// open imp

	}

	@Override
	public boolean withdrawlAmt(double amt, int accNo, int pin)
			throws CustomerNotFound {

		return dao.withdrawlAmt(amt, accNo, pin);// open imp

	}

	public boolean depositAmt(int accNo1, double amt1) throws CustomerNotFound {

		return dao.depositAmt(accNo1, amt1);// open imp

	}

	public boolean isName(String c_name) throws CustomerNotFound {
		Pattern pName = Pattern.compile(new String("^[A-Za-z\\s]*$"));
		Matcher match = pName.matcher(c_name);
		if (match.matches() == true) {
			return true;
		} else {
			return false;
		}

	}

	public boolean isAddr(String c_addr) throws CustomerNotFound {
		Pattern pat = Pattern.compile(new String("[A-Za-z0-9]+"));
		Matcher match = pat.matcher(c_addr);
		if (match.matches() == true) {
			return true;
		} else {
			return false;
		}

	}

	public boolean isPhno(String c_ph) throws CustomerNotFound {
		Pattern pat = Pattern.compile(new String("[0-9]{10}"));
		Matcher match = pat.matcher(c_ph);
		if (match.matches() == true) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isPan(String c_pan) throws CustomerNotFound {
		Pattern pat = Pattern.compile(new String("[A-Z]+[0-9]+"));
		Matcher match = pat.matcher(c_pan);
		if (match.matches() == true) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isAdhar(String c_adhar) throws CustomerNotFound {
		Pattern pat = Pattern.compile(new String("[0-9]{12}"));
		Matcher match = pat.matcher(c_adhar);
		if (match.matches() == true) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isemail(String c_email) throws CustomerNotFound {
		String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
		java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
		java.util.regex.Matcher m = p.matcher(c_email);
		return m.matches();
	}

	public boolean show_balance(int accno3, int pin2) throws CustomerNotFound {

		return dao.show_balance(accno3, pin2);
	}

	public boolean fundTransfer(int source_accno, int s_pin,
			int destination_accno, Double transferAmt) throws CustomerNotFound

	{

		return dao.fundTransfer(source_accno, s_pin, destination_accno,
				transferAmt);
	}

	@Override
	public List<PrintTransaction> printTransaction(int account)
			throws CustomerNotFound {
		return dao.print_transaction(account);

	}
}