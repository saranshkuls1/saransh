package com.capg.pp.cust_dao;

import java.util.List;

import com.capg.pp.cust_bean.PrintTransaction;
import com.capg.pp.cust_bean.customer;
import com.capg.pp.cust_exception.CustomerNotFound;

public interface ICustomerDao { // Interface for DAO layer

	public int addCustomer(customer c) throws CustomerNotFound;

	public boolean withdrawlAmt(double amt, int accNo, int pin) // method
																// declaration
			throws CustomerNotFound;

	public boolean depositAmt(int accNo1, double amt1) throws CustomerNotFound;

	public boolean show_balance(int accno3, int pin2) throws CustomerNotFound;

	public boolean fundTransfer(int source_accno, int s_pin,
			int destination_accno, Double transferAmt) throws CustomerNotFound;

	public List<PrintTransaction> print_transaction(int trans_accNo)
			throws CustomerNotFound;
}
