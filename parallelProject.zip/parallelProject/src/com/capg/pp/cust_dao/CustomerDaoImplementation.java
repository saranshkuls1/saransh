package com.capg.pp.cust_dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.capg.pp.cust_bean.PrintTransaction;
import com.capg.pp.cust_bean.customer;
import com.capg.pp.cust_exception.CustomerNotFound;
import com.capg.pp.cust_utility.JPAUtil;

public class CustomerDaoImplementation implements ICustomerDao {
	private EntityManager entityManager = null;
	PrintTransaction tran=null;
	Scanner sc= new Scanner(System.in);
	
	@Override
	public int addCustomer(customer c) throws CustomerNotFound {
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			entityManager.persist(c); // add in table
			entityManager.getTransaction().commit();
			// transaction.commit();
		} catch (PersistenceException e) {
			e.printStackTrace();

			throw new CustomerNotFound(e.getMessage());
		} finally {
			entityManager.close();
		}
return c.getAccountNo();
	}

	@Override
	public boolean withdrawlAmt(double amt, int accNo, int pin)
			throws CustomerNotFound {
		try {
			entityManager = JPAUtil.getEntityManager();
			tran= new PrintTransaction();
			entityManager.getTransaction().begin();
			customer customer = entityManager.find(customer.class, accNo);

			if (customer.getAccountNo() == accNo && customer.getAccPin() == pin) {
				Double current_balance = customer.getBalance();
				current_balance = current_balance - amt;
				customer.setBalance(current_balance);
				entityManager.merge(customer);
				tran.setAccountNumber(accNo);
				tran.setTransactions("Withdrawal: "+amt);
				entityManager.persist(tran);
				entityManager.getTransaction().commit();
	System.out.println("your account balance is: "
						+ customer.getBalance());

			} else
				System.out.println("Invalid Credentials");
		} catch (PersistenceException e) {
			e.printStackTrace();
			throw new CustomerNotFound(e.getMessage());
		} finally {
			entityManager.close();
		}
	return true;
	}

	@Override
	public boolean depositAmt(int accNo1, double amt1) throws CustomerNotFound {
		try {
			entityManager = JPAUtil.getEntityManager();
			tran= new PrintTransaction();
			entityManager.getTransaction().begin();
			customer cust = entityManager.find(customer.class, accNo1);
	//		System.out.println(cust.getBalance());//
			Double current_balance = cust.getBalance();
			current_balance = current_balance + amt1;
			cust.setBalance(current_balance);
			entityManager.merge(cust);
			tran.setAccountNumber(accNo1);
			tran.setTransactions("Deposited : "+amt1);
			entityManager.persist(tran);
			entityManager.getTransaction().commit();

			System.out.println("Account Balance is: " + cust.getBalance());

		} catch (PersistenceException e) {
			e.printStackTrace();
			// TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		} finally {
			entityManager.close();
		}
return true;
	}

	@Override
	public boolean show_balance(int accno3, int pin2) throws CustomerNotFound {
		try {
			entityManager = JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
			customer c = entityManager.find(customer.class, accno3);
			Double balance = c.getBalance();
			c.setBalance(balance);
			entityManager.merge(c);
			entityManager.getTransaction().commit();

			System.out.println("Account Balance is: " + c.getBalance());

		} catch (PersistenceException e) {
			e.printStackTrace();
			// TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		} finally {
			entityManager.close();
		}
return true;
	}

	@Override
	public boolean fundTransfer(int source_accno, int s_pin,
			int destination_accno, Double transferAmt) throws CustomerNotFound {

		try {
			entityManager = JPAUtil.getEntityManager();
			tran= new PrintTransaction();
			entityManager.getTransaction().begin();
			customer source_accno1 = entityManager.find(customer.class,
					source_accno);
			customer destination_accno1 = entityManager.find(customer.class,
					destination_accno);

			Double sourceAcc_bal = source_accno1.getBalance();
			Double destAcc_bal = destination_accno1.getBalance();

			sourceAcc_bal = sourceAcc_bal - transferAmt;
			tran.setAccountNumber(source_accno);
			tran.setTransactions("Withdrawal: "+transferAmt);
			entityManager.persist(tran);
			destAcc_bal = destAcc_bal + transferAmt;
			source_accno1.setBalance(sourceAcc_bal);
			destination_accno1.setBalance(destAcc_bal);

			entityManager.merge(source_accno1);
			tran.setAccountNumber(destination_accno);
			tran.setTransactions("Deposited: "+transferAmt);
			entityManager.persist(tran);
			entityManager.merge(destination_accno1);

			entityManager.getTransaction().commit();

			System.out.println("Source account balance is: "
					+ source_accno1.getBalance());
			System.out.println("Destination account balance  is: "
					+ destination_accno1.getBalance());

		} catch (PersistenceException e) {
			e.printStackTrace();
			// TODO: Log to file
			throw new CustomerNotFound(e.getMessage());
		} finally {
			entityManager.close();
		}
		return true;
	}
	public List<PrintTransaction> print_transaction(int trans_accNo) throws CustomerNotFound {
		try{
			entityManager=JPAUtil.getEntityManager();
			entityManager.getTransaction().begin();
		Query query = entityManager.createQuery("from PrintTransaction where accountNumber=?");
		query.setParameter(1, trans_accNo);
		List<PrintTransaction> empList=query.getResultList();
		return empList;
		
		}catch(PersistenceException e) {
			e.printStackTrace();
			//Log to file
			throw new CustomerNotFound(e.getMessage());
		}finally{
			entityManager.close();
		}		
		
		
	}
}
