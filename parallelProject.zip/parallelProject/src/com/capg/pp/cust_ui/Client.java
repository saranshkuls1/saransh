package com.capg.pp.cust_ui;

import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.capg.pp.cust_bean.PrintTransaction;
import com.capg.pp.cust_bean.customer;
import com.capg.pp.cust_exception.CustomerNotFound;
import com.capg.pp.cust_service.CustomerServiceImp;

/*
 @author : Saransh Kulshrestha
 Class: Client
 Date: 10/11/2018
 */

public class Client {
	public static void main(String[] args) throws CustomerNotFound { // main
																		// method
		CustomerServiceImp service = new CustomerServiceImp();
		while (true) {
			System.out // menu driven code
					.println("\t\t\t\t\t-------------------------------------------------");
			System.out.print("\t\t\t\t\t\t**WELCOME TO MY BANK**\n");
			System.out
					.println("\t\t\t\t\t-------------------------------------------------");

			System.out.println("Press 1 -> Create an account");
			System.out.println("Press 2 -> Withdraw amount");
			System.out.println("Press 3 -> Deposit amount");
			System.out.println("Press 4 -> Show Balanace");
			System.out.println("Press 5 -> Fund Transfer");
			System.out.println("Press 6 -> Print Transictions");
			System.out.println("Press 7 -> Exit \n");
			System.out
					.println("\t\t\t\t\t******************************************");

			Scanner sc = new Scanner(System.in);

			int ch = sc.nextInt();

			switch (ch) { // applying switch case on users choice
			case 1:
				customer bean = new customer();

				System.out.println("Enter customer name");
				String c_name = sc.next();
				boolean valid_name = false;
				try {
					valid_name = service.isName(c_name); // Validation for Name
				} catch (CustomerNotFound e) {

					System.out.println(e.getStatus());
				}
				boolean vvalid_name = false;
				String cc_name;
				if (!valid_name) {
					do {

						System.out.println("Enter correct name");
						cc_name = sc.next();
						try {
							vvalid_name = service.isName(cc_name);
						} catch (CustomerNotFound e) {

							System.out.println(e.getStatus());
						}
					} while (!vvalid_name);
					bean.setC_name(cc_name);
				} else
					bean.setC_name(c_name);

				System.out.println("Enter customer Address");
				String c_addr = sc.next();
				String cc_addr;
				boolean valid_addr = false;
				try {
					valid_addr = service.isAddr(c_addr);
				} catch (CustomerNotFound e) {

					System.out.println(e.getStatus());
				}
				boolean vvalid_addr = false;
				if (!valid_addr) {
					do {

						System.out.println("Enter correct Adress:");
						cc_addr = sc.next();
						try {
							vvalid_addr = service.isAddr(cc_addr);
						} catch (CustomerNotFound e) {

							System.out.println(e.getStatus());
						}
					} while (!vvalid_addr);
					bean.setC_addr(cc_addr);
				} else
					bean.setC_addr(c_addr);

				System.out.println("Enter customer email id");
				String c_email = sc.next();
				String cc_email;
				boolean valid_email = false;
				try {
					valid_email = service.isemail(c_email);
				} catch (CustomerNotFound e) {

					System.out.println(e.getStatus());
				}
				boolean vvalid_email = false;
				if (!valid_email) {
					do {

						System.out.println("Enter correct email:");
						cc_email = sc.next();
						try {
							vvalid_email = service.isemail(cc_email);
						} catch (CustomerNotFound e) {

							System.out.println(e.getStatus());
						}
					} while (!vvalid_email);
					bean.setC_email(cc_email);
				} else
					bean.setC_email(c_email);

				System.out.println("Enter customer phone_number");

				String c_ph = sc.next();
				boolean valid_ph = false;
				try {
					valid_ph = service.isPhno(c_ph);
				} catch (CustomerNotFound e) {

					System.out.println(e.getStatus());
				}
				boolean vvalid_ph = false;
				String cc_ph;
				if (!valid_ph) {
					do {

						System.out.println("Enter correct phone_number:");
						cc_ph = sc.next();
						try {
							vvalid_ph = service.isPhno(cc_ph);
						} catch (CustomerNotFound e) {

							e.printStackTrace();
						}
					} while (!vvalid_ph);
					bean.setC_ph(cc_ph);
				} else
					bean.setC_ph(c_ph);

				System.out.println("Enter customer PAN card number");

				String c_pan = sc.next();
				boolean valid_pan = false;
				try {
					valid_pan = service.isPan(c_pan);
				} catch (CustomerNotFound e) {

					e.printStackTrace();
				}
				boolean vvalid_pan = false;
				String cc_pan;
				if (!valid_pan) {
					do {

						System.out.println("Enter correct PAN number:");
						cc_pan = sc.next();
						try {
							vvalid_pan = service.isPan(cc_pan);
						} catch (CustomerNotFound e) {

							e.printStackTrace();
						}
					} while (!vvalid_pan);
					bean.setC_pan(cc_pan);
				} else
					bean.setC_pan(c_pan);

				System.out.println("Enter customer AADHAR card number");
				String c_adhar = sc.next();
				boolean valid_adhar = false;
				try {
					valid_adhar = service.isAdhar(c_adhar);
				} catch (CustomerNotFound e) {

					e.printStackTrace();
				}
				boolean vvalid_adhar = false;
				String cc_adhar;
				if (!valid_adhar) {
					do {

						System.out.println("Enter correct AADHAR number:");
						cc_adhar = sc.next();
						try {
							vvalid_adhar = service.isAdhar(cc_adhar);
						} catch (CustomerNotFound e) {

							e.printStackTrace();
						}
					} while (!vvalid_adhar);
					bean.setC_adhar(cc_adhar);
				} else
					bean.setC_adhar(c_adhar);

				System.out.println("Enter Initial Balance");
				double bal = sc.nextDouble();
				bean.setBalance(bal);

				Random rd1 = new Random();
				int accountNo = 1000 + rd1.nextInt(9999);
				System.out.println();
				bean.setAccountNo(accountNo);

				Random rd2 = new Random();
				int accpin = 1000 + rd1.nextInt(5550);
				System.out.println();
				bean.setAccPin(accpin);

				try {
					int isValid = service.addCustomer(bean);
					System.out.println(isValid);
					if (isValid!=0) {

						System.out.println("Account created");
					} else {
						System.out.println("Account not created");
					}
				} catch (CustomerNotFound e) {

					System.out.println(e.getStatus());
				}
				boolean isValid = true;
				int a = bean.getAccountNo();

				System.out.println(bean);

				break;
			case 2:
				System.out.println("Enter account number");
				int accNo = sc.nextInt();
				System.out.println("Enter pin");
				int pin = sc.nextInt();
				System.out.println("Enter amount to be withdrawl");
				double amt = sc.nextFloat();

				customer c = null;
				try {
					boolean isValidWithdrawl = service.withdrawlAmt(amt, accNo,
							pin);
					if (isValidWithdrawl) {

						System.out.println("Amount withdrwal succesfully");
					} else {
						System.out.println("Invalid Credentials");
					}
				} catch (CustomerNotFound e) {

					System.out.println(e.getStatus());
				}

				break;
			case 3:

				System.out.println("Enter Account number");
				int accNo1 = sc.nextInt();
				System.out.println("Enter amt to deposit");
				double amt1 = sc.nextDouble();

				customer c1 = null;
				try {
					boolean isValidDeposit = service.depositAmt(accNo1, amt1);
					if (isValidDeposit) {

						System.out.println("Amount Deposited Succesfully");
					} else {
						System.out.println("Invalid Credentials");
					}
				} catch (CustomerNotFound e) {

					System.out.println(e.getStatus());
				}

				break;
			case 4:
				/*
				 * System.out
				 * .println("Enter account number and pin to show balance");
				 */

				System.out.println("Enter account number");
				int accno3 = sc.nextInt();

				System.out.println("Enter pin");
				int pin2 = sc.nextInt();

				try {
					boolean isValidBalance = service.show_balance(accno3, pin2);
					if (isValidBalance) {

						System.out.println("**BALANCE**");
					} else {
						System.out.println("Invalid Credentials");
					}

				} catch (CustomerNotFound e) {

					System.out.println(e.getStatus());
				}

				break;
			case 5:
				System.out.println("Enter your account number");
				int source_accno = sc.nextInt();

				System.out.println("Enter your pin");
				int s_pin = sc.nextInt();

				System.out.println("Enter amount you want to transfer");
				double transferAmt = sc.nextDouble();

				System.out
						.println("Enter ACCOUNT NUMBER to which you want to transfer ");
				int destination_accno = sc.nextInt();

				try {
					boolean isValidTransfer = service
							.fundTransfer(source_accno, s_pin,
									destination_accno, transferAmt);
					if (isValidTransfer) {

						System.out.println("Fund Transfered Succesfully");
					} else {
						System.out.println("Invalid Credentials");
					}
				} catch (CustomerNotFound e) {
					System.out.println(e.getStatus());
				}
				System.out
						.println("Amount transfered to: " + destination_accno);

				break;

			case 6:
				System.out.println("Enter  your  Account number : ");
				int account = sc.nextInt();
				List<PrintTransaction> list = service.printTransaction(account);
				showDetails(list);

				break;
			case 7:

				System.exit(0);

				break;

			default:
				break;
			}

		}

	}

	private static void showDetails(List<PrintTransaction> list) {
		Iterator<PrintTransaction> it = list.iterator();
		while (it.hasNext()) {
			System.out.println(it.next());
		}

	}
}
