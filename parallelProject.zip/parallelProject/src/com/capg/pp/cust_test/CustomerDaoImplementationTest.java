package com.capg.pp.cust_test;

import org.junit.Test;
import static org.junit.Assert.*;
import com.capg.pp.cust_bean.customer;
import com.capg.pp.cust_exception.CustomerNotFound;
import com.capg.pp.cust_service.CustomerServiceImp;

public class CustomerDaoImplementationTest {

	customer cust= null;
	CustomerServiceImp service= null;
	@Test
	public void testAddCustomer() throws CustomerNotFound {
		cust= new customer();
		service= new CustomerServiceImp();
		cust.setAccountNo(1122);
		cust.setAccPin(1222);
		cust.setBalance(1110);
		cust.setC_addr("banglore");
		cust.setC_adhar("159564951753");
		cust.setC_email("ram@gmail.com");
		cust.setC_name("ram");
		cust.setC_pan("ZAX445");
		cust.setC_ph("4512451278");
		int account= service.addCustomer(cust);
		System.out.println(account);
		assertEquals(1122, account, 0);
		
	}

/*	@Test
	public void testWithdrawlAmt() throws CustomerNotFound {
		cust= new customer();
		service= new CustomerServiceImp();
	boolean valid=	service.withdrawlAmt(100, 1111, 1212);
		assertTrue(valid);
	}
*/
/*	@Test
	public void testDepositAmt() throws CustomerNotFound {
		cust= new customer();
		service= new CustomerServiceImp();
boolean valid=service.depositAmt(1111,500);
assertTrue(valid);
	}
*/
	/*@Test
	public void testShow_balance() throws CustomerNotFound {
		cust= new customer();
		service= new CustomerServiceImp();
boolean valid=service.show_balance(1111,1245);
assertTrue(valid);	
	}
*/
	/*@Test
	public void testFundTransfer() throws CustomerNotFound {
			cust= new customer();
		service= new CustomerServiceImp();
boolean valid=service.fundTransfer(1111,2222, 3333,500.0);
assertTrue(valid);
}*/
/*
	@Test
	public void testPrint_transaction() {
		fail("Not yet implemented");
	}
*/
}
