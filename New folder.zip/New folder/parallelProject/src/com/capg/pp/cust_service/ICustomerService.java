package com.capg.pp.cust_service;

import com.capg.pp.cust_bean.customer;


public interface ICustomerService {
	public boolean addCustomer(int a, customer c);
	public customer withdrawlAmt(double amt,int accNo, int pin);
	public customer depositAmt(int accNo1,double amt1);
	public customer show_balance(int accno3,int pin2);
	public customer fundTransfer(int accno5 ,int pin5 ,int transferAcc ,double transferAmt);
}
