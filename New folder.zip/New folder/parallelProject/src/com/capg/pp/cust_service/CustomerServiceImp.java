package com.capg.pp.cust_service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.pp.cust_bean.customer;
import com.capg.pp.cust_dao.CustomerDaoImp;

public class CustomerServiceImp implements ICustomerService {

	CustomerDaoImp dao = new CustomerDaoImp();

	public boolean addCustomer(int a,customer c) {
		// TODO Auto-generated method stub
		return dao.addCustomer(a,c);// open imp

	}

	
	public customer withdrawlAmt(double amt,int accNo,int pin) {
		// TODO Auto-generated method stub
		return dao.withdrawlAmt(amt,accNo,pin);// open imp

	}
	
	public customer depositAmt(int accNo1,double amt1) {
		// TODO Auto-generated method stub
		return dao.depositAmt(accNo1,amt1);// open imp

	}	
	

	public boolean isName(String c_name) {
		Pattern pName = Pattern.compile(new String("^[a-zA-Z\\s]*$"));
		Matcher match = pName.matcher(c_name);
		if (match.matches() == true) {
			return true;
		} else {
			return false;
		}

	}

	public boolean isAddr(String c_addr) {
		Pattern pat = Pattern.compile(new String("[a-z]+"));
		Matcher match = pat.matcher(c_addr);
		if (match.matches() == true) {
			return true;
		} else {
			return false;
		}

	}

	public boolean isPhno(String c_ph) {
		Pattern pat = Pattern.compile(new String("[0-9]{10}"));
		Matcher match = pat.matcher(c_ph);
		if (match.matches() == true) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isPan(String c_pan) {
		Pattern pat = Pattern.compile(new String("[A-Z]+[0-9]+"));
		Matcher match = pat.matcher(c_pan);
		if (match.matches() == true) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isAdhar(String c_adhar) {
		Pattern pat = Pattern.compile(new String("[0-9]{12}"));
		Matcher match = pat.matcher(c_adhar);
		if (match.matches() == true) {
			return true;
		} else {
			return false;
		}
	}

	public boolean isemail(String c_email) {
		 String ePattern = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$";
	        java.util.regex.Pattern p = java.util.regex.Pattern.compile(ePattern);
	        java.util.regex.Matcher m = p.matcher(c_email);
	        return m.matches();
	}

	public float withdraw(float amt) {
		// TODO Auto-generated method stub
		return 0;
	}

	public customer show_balance(int accno3,int pin2){
		
		return dao.show_balance(accno3 , pin2);
	}
	

	public customer fundTransfer(int accno5 ,int pin5 ,int transferAcc ,double transferAmt)

	{
		
		return dao.fundTransfer(accno5,pin5,transferAcc,transferAmt);
	}
}