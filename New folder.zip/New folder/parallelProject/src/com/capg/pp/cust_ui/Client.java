package com.capg.pp.cust_ui;

import java.util.Random;
import java.util.Scanner;

import com.capg.pp.cust_bean.customer;
import com.capg.pp.cust_service.CustomerServiceImp;

public class Client {
	public static void main(String[] args) {
		CustomerServiceImp service = new CustomerServiceImp();
/*		customer bean = new customer();
*/		while (true) {

			System.out.println("WELCOME TO MY BANK");
			System.out.println("Pres 1 -> Create an account");
			System.out.println("Pres 2 -> Withdraw amount");
			System.out.println("Pres 3 -> Deposit amount");
			System.out.println("Pres 4 -> Show Balanace");
			System.out.println("Pres 5 -> Fund Transfer");
			System.out.println("Pres 6 -> Print Transictions");
			System.out.println("Pres 7 -> Exit \n");

			Scanner sc = new Scanner(System.in);

			int ch = sc.nextInt();

			switch (ch) {
			case 1:
				customer bean = new customer();

				

				System.out.println("enter customer name");
				String c_name = sc.next();
				boolean valid_name = service.isName(c_name);
				boolean vvalid_name;
				String cc_name;
				if (!valid_name) {
					do {

						System.out.println("enter correct name");
						cc_name = sc.next();
						vvalid_name = service.isName(cc_name);
					} while (!vvalid_name);
					bean.setC_name(cc_name);
				} else
					bean.setC_name(c_name);

				System.out.println("enter customer Address");
				String c_addr = sc.next();
				String cc_addr;
				boolean valid_addr = service.isAddr(c_addr);
				boolean vvalid_addr;
				if (!valid_addr) {
					do {

						System.out.println("enter correct Adress:");
						cc_addr = sc.next();
						vvalid_addr = service.isAddr(cc_addr);
					} while (!vvalid_addr);
					bean.setC_addr(cc_addr);
				} else
					bean.setC_addr(c_addr);

				System.out.println("enter customer email id");
				String c_email = sc.next();
				String cc_email;
				boolean valid_email = service.isemail(c_email);
				boolean vvalid_email;
				if (!valid_email) {
					do {

						System.out.println("enter correct email:");
						cc_email = sc.next();
						vvalid_email = service.isemail(cc_email);
					} while (!vvalid_email);
					bean.setC_email(cc_email);
				} else
					bean.setC_email(c_email);


				System.out.println("enter customer phone_number");

				String c_ph = sc.next();
				boolean valid_ph = service.isPhno(c_ph);
				boolean vvalid_ph;
				String cc_ph;
				if (!valid_ph) {
					do {

						System.out.println("enter correct phone_number:");
						cc_ph = sc.next();
						vvalid_ph = service.isPhno(cc_ph);
					} while (!vvalid_ph);
					bean.setC_ph(cc_ph);
				} else
					bean.setC_ph(c_ph);

				System.out.println("enter customer PAN card number");

				String c_pan = sc.next();
				boolean valid_pan = service.isPan(c_pan);
				boolean vvalid_pan;
				String cc_pan;
				if (!valid_pan) {
					do {

						System.out.println("enter correct PAN number:");
						cc_pan = sc.next();
						vvalid_pan = service.isPan(cc_pan);
					} while (!vvalid_pan);
					bean.setC_pan(cc_pan);
				} else
					bean.setC_pan(c_pan);

				System.out.println("enter customer AADHAR card number");
				String c_adhar = sc.next();
				boolean valid_adhar = service.isAdhar(c_adhar);
				boolean vvalid_adhar;
				String cc_adhar;
				if (!valid_adhar) {
					do {

						System.out.println("enter correct AADHAR number:");
						cc_adhar = sc.next();
						vvalid_adhar = service.isAdhar(cc_adhar);
					} while (!vvalid_adhar);
					bean.setC_adhar(cc_adhar);
				} else
					bean.setC_adhar(c_adhar);
			

				System.out.println("enter balance");
				double bal = sc.nextDouble();
				bean.setBalance(bal);

				Random rd1 = new Random();
				int accountNo = 1000 + rd1.nextInt(9999);
				System.out.println();
				bean.setAccountNo(accountNo);

				Random rd2 = new Random();
				int accpin = 1000 + rd1.nextInt(5550);
				System.out.println();
				bean.setAccPin(accpin);

				boolean isAdded = service.addCustomer(accountNo, bean);
				boolean isValid = true;
				int a = bean.getAccountNo();
				// boolean isAdded0 = service.addCustomer(a, bean);

				System.out.println("account created !");
				System.out.println(bean);

				break;
			case 2:
				System.out.println("enter account number");
				int accNo=sc.nextInt();
				System.out.println("enter pin");
				int pin=sc.nextInt();
				System.out.println("Enter amount to be withdrawl");
				double amt = sc.nextFloat();
			//customer c=new customer();
			customer c = service.withdrawlAmt(amt, accNo, pin);
		//	System.out.println("c"+c);
			System.out.println("balance is : "+c.getBalance());
				//double baln = service.withdraw(amt);
				break;
			case 3:

				System.out.println("enter Account number");
				int accNo1=sc.nextInt();
				System.out.println("enter amt to deposit");
				double amt1=sc.nextDouble();

				 customer c1=service.depositAmt(accNo1,amt1);
				 System.out.println(c1.getBalance());
				//1 System.out.println("amount depsoite to account number "+c1.getAccountNo()+" "+c1.getBalance());
				break;
			case 4:
				System.out.println("enter account number and pin to show balance");
				
				
				System.out.println("enter account number");
				int accno3 = sc.nextInt();
				
				System.out.println("enter pin");
				int pin2 = sc.nextInt();
			
				customer b = service.show_balance(accno3, pin2);
					
				break;
			case 5:
				System.out.println("enter your account number");
				int accno5 = sc.nextInt();
				
				System.out.println("enter your pin");
				int pin5 = sc.nextInt();
				
				System.out.println("enter amount you want to transfer");
				double transferAmt = sc.nextDouble();
				
				System.out.println("enter account number to which you want to transfer amount");
				int transferAcc = sc.nextInt();
				
				
				customer c5 = service.fundTransfer(accno5 , pin5 , transferAcc , transferAmt);
				System.out.println("amount transfered to: " + transferAcc);
				
				
				
				break;
			case 6:

				break;
			case 7:

				break;

			default:
				break;
			}

		}

	}
}
