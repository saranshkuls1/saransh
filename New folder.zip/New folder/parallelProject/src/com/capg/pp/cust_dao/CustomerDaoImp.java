package com.capg.pp.cust_dao;

import java.util.HashMap;
import java.util.Map;

import com.capg.pp.cust_bean.customer;

public class CustomerDaoImp implements ICustomerDao {
Map<Integer, customer> custList=new HashMap<Integer, customer>();
	@Override
	public boolean addCustomer(int a,customer c) {
		custList.put(a, c);
		System.out.println(custList);
		return false;
	}

	public customer withdrawlAmt(double amt,int accNo, int pin)
	{
customer cust = null;
		
		for (customer custList : custList.values()) 
		{
		if(custList.getAccountNo() == accNo)
		
		
			{
				double amt1 = custList.getBalance();
				if(amt < amt1)
				{
					amt1 = amt1 - amt;
					
					custList.setBalance(amt1);
					cust = custList;
					
					
					
				}
				
			}
		}
		
		return cust;
	}
	
public customer depositAmt(int accno1,double amt1) {
	customer cust = null;
	
	for (customer custList : custList.values()) 
	{
	if(custList.getAccountNo() == accno1)
	{
		 //System.out.println("Value = " + custList.getBalance());
	}
	   
	}
	
	for(customer custList : custList.values())
	{
		if(custList.getAccountNo() == accno1)
			
	
		{
			
			double amt = custList.getBalance();
			
			
			amt = amt + amt1;
			custList.setBalance(amt);
			
			
			
			cust = custList;
		}
	}
	return cust;
	
}

public customer show_balance(int accno3 , int pin2) 
{	
	customer b = null;
	for (customer custList2 : custList.values() ) 
	{
	if(custList2.getAccountNo() == accno3 && custList2.getAccPin() == pin2)
	{
	
		 System.out.println("Value = " + custList2.getBalance());
	}
	else System.out.println("please enter valid pin and account number");
	   
	}	
	return b;
}


public customer fundTransfer(int accno5 ,int pin5 ,int transferAcc ,double transferAmt){
	
	customer c5 = null;
	
	for (customer custList1 : custList.values()) 
	{
			if(custList1.getAccountNo() == accno5 && custList1.getAccPin() == pin5 )
		{
			double amt = custList1.getBalance();
			if(transferAmt < amt)
			{
				double amt1 = custList1.getBalance();
				amt1 = amt1 - transferAmt;
				for (customer custList2 : custList.values()) 
				{
				if(custList.containsKey(transferAcc) && custList.containsKey(accno5))
				{
					 double acc_to = custList2.getBalance();
					 acc_to = acc_to + transferAmt;
					custList2.setBalance(acc_to);	
					custList1.setBalance(amt1);
					c5 = custList1;
					
					System.out.println(custList2.getBalance());
					
				}
				else 
				{
					System.out.println("Insufficient Amount");
				}
			}
				
			
			
		}
	}
	}
	
	return c5;	
	
	
}
}
